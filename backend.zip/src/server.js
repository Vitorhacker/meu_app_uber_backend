// src/server.js
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const helmet = require("helmet");
require("dotenv").config();

// Conexão DB
const pool = require("./config/db");

const app = express();
const PORT = process.env.PORT || 5000;

// ======================
// Middlewares
// ======================
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));
app.use(helmet());

// ======================
// Rotas principais da API
// ======================
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/rides", require("./routes/rideRoutes"));
app.use("/api/payments", require("./routes/paymentRoutes"));
app.use("/api/drivers", require("./routes/driverRoutes"));
app.use("/api/passengers", require("./routes/passengerRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/wallet", require("./routes/walletRoutes"));
app.use("/api/support", require("./routes/supportRoutes"));
app.use("/api/ratings", require("./routes/ratingRoutes"));
app.use("/api/chat", require("./routes/chatRoutes"));
app.use("/api/location", require("./routes/locationRoutes"));
app.use("/api/transactions", require("./routes/transactionRoutes"));
app.use("/api/vehicles", require("./routes/vehicleRoutes"));
app.use("/api/notifications", require("./routes/notificationRoutes"));

// ======================
// Webhooks (PicPay)
// ======================
app.use("/api/webhooks/payments", require("./routes/paymentWebhookRoutes"));

// ======================
// Rota de retorno do PicPay (usuário volta após pagamento)
// ======================
app.get("/app/checkout-return", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Pagamento Processado</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: #f4f4f9;
          }
          .card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            max-width: 400px;
            margin: auto;
            box-shadow: 0px 2px 8px rgba(0,0,0,0.1);
          }
          h1 {
            color: #22c55e;
          }
          p {
            color: #333;
          }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>✅ Pagamento em processamento!</h1>
          <p>Obrigado por utilizar nosso app.<br>
          Assim que o PicPay confirmar o pagamento,<br>
          sua corrida será liberada automaticamente.</p>
        </div>
      </body>
    </html>
  `);
});

// ======================
// Healthcheck
// ======================
app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", db: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", db: "disconnected" });
  }
});

// ======================
// Ativar polling do PicPay
// ======================
if (process.env.ENABLE_PICPAY_POLLING === "true") {
  const { startPolling } = require("./jobs/picpayPollingJob");
  startPolling();
}

// ======================
// Rota inicial de teste
// ======================
app.get("/", (req, res) => {
  res.send("🚀 API do App de Transporte funcionando!");
});

// ======================
// Middleware global de erros
// ======================
app.use((err, req, res, next) => {
  console.error("❌ Erro não tratado:", err);
  res.status(500).json({ error: "Erro interno do servidor" });
});

// ======================
// Iniciar servidor
// ======================
const server = app.listen(PORT, () => {
  console.log(`✅ Servidor rodando na porta ${PORT}`);
});

// ======================
// Graceful shutdown
// ======================
process.on("SIGTERM", async () => {
  console.log("🔻 Encerrando servidor...");
  await pool.end();
  server.close(() => {
    console.log("✅ Conexões fechadas. Servidor encerrado.");
    process.exit(0);
  });
});
