// src/jobs/picpayPollingJob.js
const pool = require("../db");
const picpayService = require("../services/picpayService");
const { PLATFORM_FEE_PERCENT } = process.env;

const POLL_INTERVAL_MS = parseInt(process.env.PICPAY_POLL_INTERVAL_MS || "60000", 10);
const BATCH = parseInt(process.env.PICPAY_POLL_BATCH || "20", 10);

let running = false;

async function processOnePaymentRow(payment) {
  try {
    const trans = payment.transacao_id;
    if (!trans) return;

    console.log(`🔎 Verificando pagamento id=${payment.id}, ride=${payment.ride_id}, trans=${trans}`);

    const remote = await picpayService.getPayment(trans);
    const status = (remote && remote.status) ? String(remote.status).toLowerCase() : null;
    if (status !== "paid" && status !== "success") {
      if (status === "expired") {
        await pool.query("UPDATE payments SET status = $1 WHERE id = $2", ["expirado", payment.id]);
      }
      return;
    }

    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const payLock = await client.query("SELECT * FROM payments WHERE id = $1 FOR UPDATE", [payment.id]);
      if (payLock.rows.length === 0) { await client.query("COMMIT"); return; }
      const pay = payLock.rows[0];
      if (pay.status === "pago") { await client.query("COMMIT"); return; }

      // Update payment
      await client.query("UPDATE payments SET status = $1, data_pagamento = NOW() WHERE id = $2", ["pago", pay.id]);

      // Ride
      const rideRes = await client.query("SELECT * FROM rides WHERE id = $1 FOR UPDATE", [pay.ride_id]);
      if (rideRes.rows.length === 0) { await client.query("COMMIT"); return; }
      const ride = rideRes.rows[0];

      const feePercent = parseFloat(PLATFORM_FEE_PERCENT || "0.20");
      const platformFee = Number((parseFloat(pay.valor) * feePercent).toFixed(2));
      const driverShare = Number((parseFloat(pay.valor) - platformFee).toFixed(2));

      // passenger wallet debit
      {
        const wPass = await client.query("SELECT id, balance FROM wallets WHERE user_id = $1 FOR UPDATE", [ride.passenger_id]);
        let newPassBalance = 0;
        if (wPass.rows.length === 0) {
          newPassBalance = -Number(pay.valor);
          await client.query("INSERT INTO wallets (user_id, balance, reserved, currency, updated_at) VALUES ($1,$2,0,'BRL',NOW())", [ride.passenger_id, newPassBalance]);
        } else {
          const cur = Number(wPass.rows[0].balance || 0);
          newPassBalance = cur - Number(pay.valor);
          await client.query("UPDATE wallets SET balance = $1, updated_at = NOW() WHERE id = $2", [newPassBalance, wPass.rows[0].id]);
        }
        await client.query(
          `INSERT INTO ledger_entries (user_id, related_table, related_id, type, amount, balance_after, metadata, idempotency_key)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [ride.passenger_id, "payments", pay.id, "ride_payment_debit", -Number(pay.valor), newPassBalance, JSON.stringify({ ride_id: ride.id }), String(pay.id)]
        );
      }

      // driver credit
      {
        const wDriver = await client.query("SELECT id, balance FROM wallets WHERE user_id = $1 FOR UPDATE", [ride.driver_id]);
        let newDriverBalance = 0;
        if (wDriver.rows.length === 0) {
          newDriverBalance = driverShare;
          await client.query("INSERT INTO wallets (user_id, balance, reserved, currency, updated_at) VALUES ($1,$2,0,'BRL',NOW())", [ride.driver_id, newDriverBalance]);
        } else {
          const cur = Number(wDriver.rows[0].balance || 0);
          newDriverBalance = Number((cur + driverShare).toFixed(2));
          await client.query("UPDATE wallets SET balance = $1, updated_at = NOW() WHERE id = $2", [newDriverBalance, wDriver.rows[0].id]);
        }
        await client.query(
          `INSERT INTO ledger_entries (user_id, related_table, related_id, type, amount, balance_after, metadata, idempotency_key)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [ride.driver_id, "payments", pay.id, "driver_earn", Number(driverShare), newDriverBalance, JSON.stringify({ ride_id: ride.id }), String(pay.id)]
        );
      }

      // platform credit
      const platformUserId = parseInt(process.env.PLATFORM_USER_ID || "0", 10);
      if (platformUserId) {
        const wPlat = await client.query("SELECT id, balance FROM wallets WHERE user_id = $1 FOR UPDATE", [platformUserId]);
        let newPlatBalance = 0;
        if (wPlat.rows.length === 0) {
          newPlatBalance = platformFee;
          await client.query("INSERT INTO wallets (user_id, balance, reserved, currency, updated_at) VALUES ($1,$2,0,'BRL',NOW())", [platformUserId, newPlatBalance]);
        } else {
          const cur = Number(wPlat.rows[0].balance || 0);
          newPlatBalance = Number((cur + platformFee).toFixed(2));
          await client.query("UPDATE wallets SET balance = $1, updated_at = NOW() WHERE id = $2", [newPlatBalance, wPlat.rows[0].id]);
        }
        await client.query(
          `INSERT INTO ledger_entries (user_id, related_table, related_id, type, amount, balance_after, metadata, idempotency_key)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [platformUserId, "payments", pay.id, "platform_fee", Number(platformFee), newPlatBalance, JSON.stringify({ ride_id: ride.id }), String(pay.id)]
        );
      }

      // finalize ride
      await client.query("UPDATE rides SET status = $1, finalizado_em = NOW() WHERE id = $2", ["concluida", ride.id]);

      await client.query("COMMIT");
      console.log(`✅ Pagamento processado com sucesso (id=${pay.id}, ride=${ride.id})`);
    } catch (errTx) {
      await client.query("ROLLBACK");
      console.error("Erro ao processar pagamento dentro do polling job:", errTx);
    } finally {
      client.release();
    }
  } catch (err) {
    console.error("Erro processOnePaymentRow:", err);
  }
}

async function pollOnce() {
  if (running) return;
  running = true;
  try {
    const res = await pool.query(
      `SELECT * FROM payments 
       WHERE status = 'pendente' 
       AND provider = 'picpay' 
       AND transacao_id IS NOT NULL 
       ORDER BY created_at ASC 
       LIMIT $1`,
      [BATCH]
    );
    const rows = res.rows;
    for (const row of rows) {
      await processOnePaymentRow(row);
    }
  } catch (err) {
    console.error("Erro no polling PicPay:", err);
  } finally {
    running = false;
  }
}

function startPolling() {
  if (process.env.ENABLE_PICPAY_POLLING !== "true") {
    console.log("PicPay polling disabled (ENABLE_PICPAY_POLLING != 'true')");
    return;
  }
  console.log("PicPay polling started: interval", POLL_INTERVAL_MS, "ms batch", BATCH);
  pollOnce().catch((e) => console.error(e));
  setInterval(() => { pollOnce().catch((e) => console.error(e)); }, POLL_INTERVAL_MS);
}

module.exports = {
  startPolling,
  pollOnce,
};
