// src/jobs/payoutJob.js
import cron from "node-cron";
import pool from "../db.js";
import { sendPayoutToDriver } from "../services/payoutService.js";

/**
 * Job de payouts semanais
 * Roda toda segunda-feira às 02:00
 */
cron.schedule("0 2 * * 1", async () => {
  console.log("🚀 Iniciando job de payouts...");

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // 1) Seleciona motoristas com saldo >= 50
    const { rows: drivers } = await client.query(
      `SELECT u.id as driver_id, w.balance, u.bank_account
       FROM users u
       JOIN wallets w ON w.user_id = u.id
       WHERE u.role = 'driver' AND w.balance >= 50
       FOR UPDATE`
    );

    // 2) Processa cada motorista
    for (const driver of drivers) {
      const bankAccount = driver.bank_account; // precisa estar em JSON na tabela users
      const amount = parseFloat(driver.balance);

      try {
        console.log(`💸 Iniciando payout para driver=${driver.driver_id}, valor=${amount}`);

        // chama serviço que dispara payout no PicPay
        await sendPayoutToDriver(driver.driver_id, amount, bankAccount);

        // zera saldo da carteira após criar payout
        await client.query(
          `UPDATE wallets SET balance = 0, updated_at = NOW() WHERE user_id = $1`,
          [driver.driver_id]
        );

        console.log(`✅ Payout criado para driver=${driver.driver_id}`);
      } catch (err) {
        console.error(`❌ Falha payout driver ${driver.driver_id}:`, err.message || err);
      }
    }

    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro no job de payouts:", err);
  } finally {
    client.release();
  }

  console.log("🏁 Job de payouts concluído.");
});
