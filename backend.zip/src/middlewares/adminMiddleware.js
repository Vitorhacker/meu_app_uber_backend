// src/middleware/adminMiddleware.js
module.exports = function requireAdmin(req, res, next) {
  try {
    if (!req.user || req.user.tipo !== "admin") {
      return res.status(403).json({ error: "Acesso negado. Somente administradores." });
    }
    next();
  } catch (err) {
    console.error("Erro no requireAdmin:", err);
    res.status(500).json({ error: "Erro interno na verificação de permissões" });
  }
};
