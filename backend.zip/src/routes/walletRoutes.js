// src/routes/walletRoutes.js
const express = require("express");
const router = express.Router();

const walletController = require("../controllers/walletController");
const authMiddleware = require("../middlewares/authMiddleware");

// Consultar saldo
router.get(
  "/balance",
  authMiddleware.verifyToken,
  walletController.getBalance
);

// Adicionar fundos (PIX, cartão)
router.post(
  "/add-funds",
  authMiddleware.verifyToken,
  walletController.addFunds
);

// Solicitar saque (apenas motoristas)
router.post(
  "/withdraw",
  authMiddleware.verifyToken,
  authMiddleware.requireRole("driver"),
  walletController.withdrawFunds
);

// Histórico da carteira
router.get(
  "/history",
  authMiddleware.verifyToken,
  walletController.getWalletHistory
);

// Listar solicitações de saque do usuário
router.get(
  "/payout-requests",
  authMiddleware.verifyToken,
  authMiddleware.requireRole("driver"),
  walletController.getPayoutRequests
);

module.exports = router;
