// src/routes/locationRoutes.js
const express = require("express");
const router = express.Router();

const locationController = require("../controllers/locationController");
const authMiddleware = require("../middlewares/authMiddleware");

// Atualizar localização do motorista em tempo real
router.post("/update", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), locationController.updateLocation);

// Buscar localização atual do motorista
router.get("/driver/:driverId", authMiddleware.verifyToken, locationController.getDriverLocation);

// Buscar localização atual do passageiro (opcional)
router.get("/passenger/:passengerId", authMiddleware.verifyToken, locationController.getPassengerLocation);

module.exports = router;