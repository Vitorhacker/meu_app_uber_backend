// src/controllers/adminController.js
const pool = require("../config/db");

// ========================
// LISTAGENS
// ========================
exports.listAllDrivers = async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM drivers ORDER BY created_at DESC");
    res.json(rows);
  } catch (err) {
    console.error("❌ listAllDrivers", err);
    res.status(500).json({ error: "Erro ao listar motoristas" });
  }
};

exports.listAllPassengers = async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM passengers ORDER BY created_at DESC");
    res.json(rows);
  } catch (err) {
    console.error("❌ listAllPassengers", err);
    res.status(500).json({ error: "Erro ao listar passageiros" });
  }
};

exports.listAllRides = async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM rides ORDER BY created_at DESC");
    res.json(rows);
  } catch (err) {
    console.error("❌ listAllRides", err);
    res.status(500).json({ error: "Erro ao listar corridas" });
  }
};

exports.listAllPayments = async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM payments ORDER BY created_at DESC");
    res.json(rows);
  } catch (err) {
    console.error("❌ listAllPayments", err);
    res.status(500).json({ error: "Erro ao listar pagamentos" });
  }
};

// ========================
// BLOQUEIOS
// ========================
exports.toggleDriverStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      "UPDATE drivers SET active = NOT active WHERE id = $1 RETURNING *",
      [id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error("❌ toggleDriverStatus", err);
    res.status(500).json({ error: "Erro ao bloquear/desbloquear motorista" });
  }
};

exports.togglePassengerStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      "UPDATE passengers SET active = NOT active WHERE id = $1 RETURNING *",
      [id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error("❌ togglePassengerStatus", err);
    res.status(500).json({ error: "Erro ao bloquear/desbloquear passageiro" });
  }
};

// ========================
// DASHBOARD
// ========================
exports.getDashboardStats = async (req, res) => {
  try {
    const drivers = await pool.query("SELECT COUNT(*) FROM drivers");
    const passengers = await pool.query("SELECT COUNT(*) FROM passengers");
    const rides = await pool.query("SELECT COUNT(*) FROM rides");
    const payments = await pool.query("SELECT COUNT(*) FROM payments");

    res.json({
      drivers: drivers.rows[0].count,
      passengers: passengers.rows[0].count,
      rides: rides.rows[0].count,
      payments: payments.rows[0].count,
    });
  } catch (err) {
    console.error("❌ getDashboardStats", err);
    res.status(500).json({ error: "Erro ao buscar estatísticas" });
  }
};

// ========================
// PAGAMENTOS (SAQUES)
// ========================
exports.listPendingPayouts = async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM payouts WHERE status = 'pending' ORDER BY created_at ASC"
    );
    res.json(rows);
  } catch (err) {
    console.error("❌ listPendingPayouts", err);
    res.status(500).json({ error: "Erro ao listar saques pendentes" });
  }
};

exports.approvePayout = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      "UPDATE payouts SET status = 'approved', approved_at = NOW() WHERE id = $1 RETURNING *",
      [id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error("❌ approvePayout", err);
    res.status(500).json({ error: "Erro ao aprovar saque" });
  }
};

exports.rejectPayout = async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      "UPDATE payouts SET status = 'rejected', rejected_at = NOW() WHERE id = $1 RETURNING *",
      [id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error("❌ rejectPayout", err);
    res.status(500).json({ error: "Erro ao rejeitar saque" });
  }
};
