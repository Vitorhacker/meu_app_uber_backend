// src/routes/driverRoutes.js
const express = require("express");
const router = express.Router();

const driverController = require("../controllers/driverController");
const authMiddleware = require("../middlewares/authMiddleware");

// Registrar motorista + veículo
router.post("/register", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), driverController.registerDriver);

// Atualizar motorista
router.put("/update/:id", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), driverController.updateDriver);

// Listar motoristas
router.get("/list", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), driverController.listDrivers);

// Detalhes de um motorista
router.get("/:id", authMiddleware.verifyToken, driverController.getDriverDetails);

// Alterar disponibilidade do motorista (on/off)
router.post("/toggle-availability/:id", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), driverController.toggleAvailability);

module.exports = router;