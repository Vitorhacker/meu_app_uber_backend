// src/routes/rideRoutes.js
const express = require("express");
const router = express.Router();

const rideController = require("../controllers/rideController");
const authMiddleware = require("../middlewares/authMiddleware");

// Solicitar corrida
router.post("/request", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), rideController.requestRide);

// Aceitar corrida
router.post("/accept/:rideId", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), rideController.acceptRide);

// Iniciar corrida
router.post("/start/:rideId", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), rideController.startRide);

// Finalizar corrida
router.post("/finish/:rideId", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), rideController.finishRide);

// Cancelar corrida (passageiro ou motorista)
router.post("/cancel/:rideId", authMiddleware.verifyToken, rideController.cancelRide);

// Rota para rastrear corrida em tempo real
router.get("/track/:rideId", authMiddleware.verifyToken, rideController.trackRide);

// Histórico de corridas (motorista ou passageiro)
router.get("/history", authMiddleware.verifyToken, rideController.getRideHistory);

module.exports = router;