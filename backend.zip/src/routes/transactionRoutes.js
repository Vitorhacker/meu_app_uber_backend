// src/routes/transactionRoutes.js
const express = require("express");
const router = express.Router();

const transactionController = require("../controllers/transactionController");
const authMiddleware = require("../middlewares/authMiddleware");

// Criar transação (quando houver movimentação financeira)
router.post("/create", authMiddleware.verifyToken, transactionController.createTransaction);

// Detalhes de uma transação específica
router.get("/:id", authMiddleware.verifyToken, transactionController.getTransactionById);

// Histórico de transações do usuário
router.get("/history/user", authMiddleware.verifyToken, transactionController.getUserTransactions);

// Listar todas transações (admin)
router.get("/all", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), transactionController.getAllTransactions);

module.exports = router;