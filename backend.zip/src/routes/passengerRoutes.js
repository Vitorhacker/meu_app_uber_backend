// src/routes/passengerRoutes.js
const express = require("express");
const router = express.Router();

const passengerController = require("../controllers/passengerController");
const authMiddleware = require("../middlewares/authMiddleware");

// Registrar passageiro
router.post("/register", passengerController.registerPassenger);

// Atualizar passageiro
router.put("/update/:id", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), passengerController.updatePassenger);

// Histórico de corridas do passageiro
router.get("/rides/:id", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), passengerController.getPassengerRides);

// Consultar saldo da carteira
router.get("/wallet/:id", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), passengerController.getWalletBalance);

// Adicionar saldo à carteira
router.post("/wallet/add/:id", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), passengerController.addWalletBalance);

module.exports = router;