// src/routes/paymentWebhookRoutes.js
const express = require("express");
const router = express.Router();

const { handlePicPayWebhook } = require("../controllers/paymentWebhookController");

// Rota pública chamada pelo PicPay
router.post("/picpay", express.json(), handlePicPayWebhook);

module.exports = router;
