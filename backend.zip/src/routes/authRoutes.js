// src/routes/authRoutes.js
const express = require("express");
const router = express.Router();

const authController = require("../controllers/authController");
const authMiddleware = require("../middlewares/authMiddleware");

// Registro de usuário (passageiro ou motorista)
router.post("/register", authController.register);

// Login
router.post("/login", authController.login);

// Refresh token
router.post("/refresh", authController.refreshToken);

// Perfil do usuário logado
router.get("/me", authMiddleware.verifyToken, authController.getProfile);

module.exports = router;