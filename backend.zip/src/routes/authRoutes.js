// src/routes/authRoutes.js
const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

// Registro e login não exigem token
router.post("/register", authController.register);
router.post("/login", authController.login);

module.exports = router;
