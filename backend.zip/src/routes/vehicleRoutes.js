// src/routes/vehicleRoutes.js
const express = require("express");
const router = express.Router();

const vehicleController = require("../controllers/vehicleController");
const authMiddleware = require("../middlewares/authMiddleware");

// Registrar veículo
router.post("/register", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), vehicleController.registerVehicle);

// Atualizar veículo
router.put("/update/:id", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), vehicleController.updateVehicle);

// Listar veículos de um motorista
router.get("/my-vehicles", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), vehicleController.getDriverVehicles);

// Remover veículo
router.delete("/delete/:id", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), vehicleController.deleteVehicle);

// Listar todos veículos (admin)
router.get("/all", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), vehicleController.getAllVehicles);

module.exports = router;