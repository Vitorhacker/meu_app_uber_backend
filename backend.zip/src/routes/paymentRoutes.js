// src/routes/paymentRoutes.js
import express from "express";
import * as paymentController from "../controllers/paymentController.js";
import * as authMiddleware from "../middlewares/authMiddleware.js";

const router = express.Router();

// Criar pagamento vinculado a corrida
router.post("/create", authMiddleware.verifyToken, paymentController.createPayment);

// Confirmar pagamento (Pix, cartão, carteira, PicPay)
router.post("/confirm", authMiddleware.verifyToken, paymentController.confirmPayment);

// Verificar status de pagamento (por referenceId ou paymentId)
router.post("/verify", authMiddleware.verifyToken, paymentController.verifyPaymentByReference);

// Verificar Historico de pagamentos do usuário
router.get("/verify", authMiddleware.verifyToken, paymentController.getUserPayments);

// Estornar pagamento (apenas admin)
router.post(
  "/refund",
  authMiddleware.verifyToken,
  authMiddleware.requireRole("admin"),
  paymentController.refundPayment
);

export default router;
