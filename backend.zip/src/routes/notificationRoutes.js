// src/routes/notificationRoutes.js
const express = require("express");
const router = express.Router();

const notificationController = require("../controllers/notificationController");
const authMiddleware = require("../middlewares/authMiddleware");

// Enviar notificação manual (admin)
router.post("/send", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), notificationController.sendNotification);

// Listar notificações do usuário
router.get("/list", authMiddleware.verifyToken, notificationController.getUserNotifications);

// Marcar notificação como lida
router.post("/read/:id", authMiddleware.verifyToken, notificationController.markAsRead);

module.exports = router;