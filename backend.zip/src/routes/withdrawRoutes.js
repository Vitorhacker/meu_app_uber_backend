const express = require("express");
const router = express.Router();
const {
  requestWithdraw,
  listWithdraws,
  approveWithdraw,
  rejectWithdraw,
  markProcessed,
} = require("../controllers/withdrawController");

// Motorista solicita saque
router.post("/", requestWithdraw);

// Admin lista todos
router.get("/", listWithdraws);

// Admin aprova
router.post("/:id/approve", approveWithdraw);

// Admin rejeita
router.post("/:id/reject", rejectWithdraw);

// Admin marca como processado
router.post("/:id/processed", markProcessed);

module.exports = router;
