// src/routes/supportRoutes.js
const express = require("express");
const router = express.Router();

const supportController = require("../controllers/supportController");
const authMiddleware = require("../middlewares/authMiddleware");

// Abrir chamado de suporte
router.post("/create", authMiddleware.verifyToken, supportController.createTicket);

// Listar chamados do usuário
router.get("/my-tickets", authMiddleware.verifyToken, supportController.getUserTickets);

// Responder chamado (admin ou suporte)
router.post("/reply/:id", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), supportController.replyTicket);

// Listar todos chamados (admin)
router.get("/all", authMiddleware.verifyToken, authMiddleware.requireRole("admin"), supportController.getAllTickets);

module.exports = router;