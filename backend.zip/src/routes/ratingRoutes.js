// src/routes/ratingRoutes.js
const express = require("express");
const router = express.Router();

const ratingController = require("../controllers/ratingController");
const authMiddleware = require("../middlewares/authMiddleware");

// Passageiro avalia motorista
router.post("/driver/:rideId", authMiddleware.verifyToken, authMiddleware.requireRole("passenger"), ratingController.rateDriver);

// Motorista avalia passageiro
router.post("/passenger/:rideId", authMiddleware.verifyToken, authMiddleware.requireRole("driver"), ratingController.ratePassenger);

// Consultar avaliações de um motorista
router.get("/driver/:driverId", ratingController.getDriverRatings);

// Consultar avaliações de um passageiro
router.get("/passenger/:passengerId", ratingController.getPassengerRatings);

module.exports = router;