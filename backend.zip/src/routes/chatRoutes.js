// src/routes/chatRoutes.js
const express = require("express");
const router = express.Router();

const chatController = require("../controllers/chatController");
const authMiddleware = require("../middlewares/authMiddleware");

// Iniciar chat entre motorista e passageiro
router.post("/start/:rideId", authMiddleware.verifyToken, chatController.startChat);

// Enviar mensagem
router.post("/send/:chatId", authMiddleware.verifyToken, chatController.sendMessage);

// Buscar mensagens de um chat
router.get("/messages/:chatId", authMiddleware.verifyToken, chatController.getMessages);

// Encerrar chat
router.post("/end/:chatId", authMiddleware.verifyToken, chatController.endChat);

module.exports = router;