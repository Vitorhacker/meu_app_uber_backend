// src/controllers/chatController.js
const db = require("../db");

// Enviar mensagem em uma corrida
exports.sendMessage = async (req, res) => {
  try {
    const senderId = req.user.id;
    const { ride_id, receiver_id, message } = req.body;

    if (!ride_id || !receiver_id || !message) {
      return res.status(400).json({ message: "ride_id, receiver_id e message são obrigatórios" });
    }

    const result = await db.query(
      `INSERT INTO chat_messages (ride_id, sender_id, receiver_id, message)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [ride_id, senderId, receiver_id, message]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao enviar mensagem:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar mensagens de uma corrida
exports.getMessagesByRide = async (req, res) => {
  try {
    const { rideId } = req.params;

    const result = await db.query(
      `SELECT m.*, u.name AS sender_name
       FROM chat_messages m
       JOIN users u ON m.sender_id = u.id
       WHERE m.ride_id = $1
       ORDER BY m.created_at ASC`,
      [rideId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar mensagens:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Apagar uma mensagem (somente quem enviou ou admin)
exports.deleteMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await db.query(
      "DELETE FROM chat_messages WHERE id = $1 AND sender_id = $2 RETURNING *",
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Mensagem não encontrada ou não pertence a você" });
    }

    res.json({ message: "Mensagem removida com sucesso" });
  } catch (err) {
    console.error("❌ Erro ao apagar mensagem:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
