// src/controllers/vehicleController.js
const db = require("../db");

// Registrar veículo
exports.registerVehicle = async (req, res) => {
  try {
    const driverId = req.user.id;
    const { plate, model, brand, year, color } = req.body;

    if (!plate || !model || !brand || !year || !color) {
      return res.status(400).json({ message: "Todos os campos do veículo são obrigatórios" });
    }

    const result = await db.query(
      `INSERT INTO vehicles (driver_id, plate, model, brand, year, color, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [driverId, plate, model, brand, year, color, "active"]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao registrar veículo:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Atualizar informações do veículo
exports.updateVehicle = async (req, res) => {
  try {
    const driverId = req.user.id;
    const { id } = req.params;
    const { plate, model, brand, year, color, status } = req.body;

    const result = await db.query(
      `UPDATE vehicles
       SET plate = COALESCE($1, plate),
           model = COALESCE($2, model),
           brand = COALESCE($3, brand),
           year = COALESCE($4, year),
           color = COALESCE($5, color),
           status = COALESCE($6, status),
           updated_at = NOW()
       WHERE id = $7 AND driver_id = $8
       RETURNING *`,
      [plate, model, brand, year, color, status, id, driverId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Veículo não encontrado ou não pertence a este motorista" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao atualizar veículo:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar veículos de um motorista
exports.getDriverVehicles = async (req, res) => {
  try {
    const driverId = req.user.id;

    const result = await db.query(
      "SELECT * FROM vehicles WHERE driver_id = $1",
      [driverId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar veículos do motorista:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar todos veículos (admin)
exports.getAllVehicles = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT v.*, u.name AS driver_name
       FROM vehicles v
       JOIN users u ON v.driver_id = u.id
       ORDER BY v.created_at DESC`
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar todos veículos:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Remover veículo
exports.deleteVehicle = async (req, res) => {
  try {
    const driverId = req.user.id;
    const { id } = req.params;

    const result = await db.query(
      "DELETE FROM vehicles WHERE id = $1 AND driver_id = $2 RETURNING *",
      [id, driverId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Veículo não encontrado ou não pertence a este motorista" });
    }

    res.json({ message: "Veículo removido com sucesso" });
  } catch (err) {
    console.error("❌ Erro ao remover veículo:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
