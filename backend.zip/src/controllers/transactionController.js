// src/controllers/transactionController.js
const db = require("../db");

// Registrar uma transação (entrada ou saída)
exports.createTransaction = async (req, res) => {
  try {
    const userId = req.user.id;
    const { amount, type, description } = req.body;

    if (!amount || !type) {
      return res.status(400).json({ message: "Valor e tipo são obrigatórios" });
    }

    if (!["credit", "debit"].includes(type)) {
      return res.status(400).json({ message: "O tipo deve ser 'credit' ou 'debit'" });
    }

    const result = await db.query(
      `INSERT INTO transactions (user_id, amount, type, description)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [userId, amount, type, description || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao registrar transação:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Buscar histórico de transações do usuário
exports.getUserTransactions = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      `SELECT * FROM transactions
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar transações do usuário:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Buscar todas transações (admin)
exports.getAllTransactions = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT t.*, u.name AS user_name
       FROM transactions t
       JOIN users u ON t.user_id = u.id
       ORDER BY t.created_at DESC`
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar todas transações:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
