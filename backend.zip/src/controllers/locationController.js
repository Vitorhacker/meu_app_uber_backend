// src/controllers/locationController.js
const db = require("../db");

// Atualizar localização do usuário (geralmente motorista)
exports.updateLocation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { latitude, longitude } = req.body;

    if (!latitude || !longitude) {
      return res.status(400).json({ message: "Latitude e longitude são obrigatórias" });
    }

    const result = await db.query(
      `INSERT INTO user_locations (user_id, latitude, longitude, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (user_id)
       DO UPDATE SET latitude = $2, longitude = $3, updated_at = NOW()
       RETURNING *`,
      [userId, latitude, longitude]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao atualizar localização:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Buscar localização de um usuário
exports.getUserLocation = async (req, res) => {
  try {
    const { userId } = req.params;

    const result = await db.query(
      "SELECT * FROM user_locations WHERE user_id = $1",
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Localização não encontrada" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao buscar localização do usuário:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Buscar motoristas próximos
exports.getNearbyDrivers = async (req, res) => {
  try {
    const { latitude, longitude, radius } = req.query;

    if (!latitude || !longitude || !radius) {
      return res.status(400).json({ message: "Latitude, longitude e radius são obrigatórios" });
    }

    const result = await db.query(
      `SELECT u.id, u.name, l.latitude, l.longitude,
        (6371 * acos(
          cos(radians($1)) * cos(radians(l.latitude)) *
          cos(radians(l.longitude) - radians($2)) +
          sin(radians($1)) * sin(radians(l.latitude))
        )) AS distance
       FROM user_locations l
       JOIN users u ON l.user_id = u.id
       WHERE u.role = 'driver'
       HAVING (6371 * acos(
          cos(radians($1)) * cos(radians(l.latitude)) *
          cos(radians(l.longitude) - radians($2)) +
          sin(radians($1)) * sin(radians(l.latitude))
        )) <= $3
       ORDER BY distance ASC`,
      [latitude, longitude, radius]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar motoristas próximos:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
