// src/controllers/passengerController.js
const pool = require("../db");

// Registrar passageiro
exports.registerPassenger = async (req, res) => {
  const { nome, email, telefone } = req.body;

  if (!nome || !email || !telefone)
    return res.status(400).json({ message: "Nome, email e telefone são obrigatórios." });

  try {
    const result = await pool.query(
      `INSERT INTO passengers (nome, email, telefone, saldo_carteira, criado_em)
       VALUES ($1, $2, $3, 0, NOW()) RETURNING *`,
      [nome, email, telefone]
    );

    res.status(201).json({ message: "Passageiro cadastrado.", passenger: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao registrar passageiro:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Atualizar passageiro
exports.updatePassenger = async (req, res) => {
  const { id } = req.params;
  const { nome, telefone } = req.body;

  try {
    const result = await pool.query(
      `UPDATE passengers SET nome = COALESCE($1, nome), telefone = COALESCE($2, telefone)
       WHERE id = $3 RETURNING *`,
      [nome, telefone, id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Passageiro não encontrado." });

    res.json({ message: "Passageiro atualizado.", passenger: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao atualizar passageiro:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Histórico de corridas do passageiro
exports.getPassengerRides = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT r.*, d.nome as motorista, v.modelo, v.placa
       FROM rides r
       LEFT JOIN drivers d ON r.driver_id = d.id
       LEFT JOIN vehicles v ON d.id = v.driver_id
       WHERE r.passenger_id = $1 ORDER BY r.data_inicio DESC`,
      [id]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar corridas do passageiro:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Consultar saldo da carteira
exports.getWalletBalance = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(`SELECT saldo_carteira FROM passengers WHERE id = $1`, [id]);

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Passageiro não encontrado." });

    res.json({ saldo: result.rows[0].saldo_carteira });
  } catch (err) {
    console.error("❌ Erro ao consultar saldo:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Adicionar saldo à carteira do passageiro
exports.addWalletBalance = async (req, res) => {
  const { id } = req.params;
  const { valor } = req.body;

  if (!valor || valor <= 0)
    return res.status(400).json({ message: "Valor inválido." });

  try {
    const result = await pool.query(
      `UPDATE passengers SET saldo_carteira = saldo_carteira + $1 WHERE id = $2 RETURNING *`,
      [valor, id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Passageiro não encontrado." });

    res.json({ message: "Saldo adicionado.", passenger: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao adicionar saldo:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};