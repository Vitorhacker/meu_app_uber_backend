// src/controllers/ratingController.js
const db = require("../db");

// Avaliar uma corrida
exports.createRating = async (req, res) => {
  try {
    const userId = req.user.id;
    const { ride_id, rated_user_id, rating, comment } = req.body;

    if (!ride_id || !rated_user_id || !rating) {
      return res.status(400).json({ message: "ride_id, rated_user_id e rating são obrigatórios" });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({ message: "A nota deve ser entre 1 e 5" });
    }

    const result = await db.query(
      `INSERT INTO ratings (ride_id, user_id, rated_user_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [ride_id, userId, rated_user_id, rating, comment || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao criar avaliação:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Buscar avaliações recebidas por um usuário (ex: motorista ou passageiro)
exports.getUserRatings = async (req, res) => {
  try {
    const { userId } = req.params;

    const result = await db.query(
      `SELECT r.*, u.name AS reviewer_name
       FROM ratings r
       JOIN users u ON r.user_id = u.id
       WHERE r.rated_user_id = $1
       ORDER BY r.created_at DESC`,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar avaliações:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Calcular média de avaliações de um usuário
exports.getUserAverageRating = async (req, res) => {
  try {
    const { userId } = req.params;

    const result = await db.query(
      `SELECT AVG(rating)::NUMERIC(3,2) AS average_rating, COUNT(*) AS total_reviews
       FROM ratings
       WHERE rated_user_id = $1`,
      [userId]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao calcular média de avaliações:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
