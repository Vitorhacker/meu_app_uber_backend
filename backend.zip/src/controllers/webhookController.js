import { getPayment } from "../services/picpayService.js";
import db from "../db.js"; // ajuste para o seu client do banco

/**
 * Webhook do PicPay
 * Recebe notificações de pagamentos (paid, expired, refunded, etc)
 */
export async function handlePicpayWebhook(req, res) {
  try {
    const { referenceId } = req.body;

    if (!referenceId) {
      return res.status(400).json({ error: "referenceId required" });
    }

    // Confirma status consultando no PicPay
    const payment = await getPayment(referenceId);

    // Exemplo: atualiza status no banco
    await db.query(
      "UPDATE rides SET payment_status = $1 WHERE reference_id = $2",
      [payment.status, referenceId]
    );

    console.log("✅ Webhook PicPay recebido:", payment);

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("❌ Erro no webhook do PicPay:", err.message);
    return res.status(500).json({ error: err.message });
  }
}
