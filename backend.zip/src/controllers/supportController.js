// src/controllers/supportController.js
const db = require("../db");

// Criar chamado de suporte
exports.createTicket = async (req, res) => {
  try {
    const userId = req.user.id;
    const { subject, message } = req.body;

    if (!subject || !message) {
      return res.status(400).json({ message: "Assunto e mensagem são obrigatórios" });
    }

    const result = await db.query(
      "INSERT INTO support_tickets (user_id, subject, message, status) VALUES ($1, $2, $3, $4) RETURNING *",
      [userId, subject, message, "open"]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao criar chamado:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar chamados do usuário
exports.getUserTickets = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      "SELECT * FROM support_tickets WHERE user_id = $1 ORDER BY created_at DESC",
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar chamados do usuário:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Responder chamado (admin)
exports.replyTicket = async (req, res) => {
  try {
    const { id } = req.params;
    const { reply } = req.body;

    if (!reply) {
      return res.status(400).json({ message: "A resposta não pode estar vazia" });
    }

    const result = await db.query(
      "UPDATE support_tickets SET reply = $1, status = $2, updated_at = NOW() WHERE id = $3 RETURNING *",
      [reply, "answered", id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Chamado não encontrado" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao responder chamado:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar todos chamados (admin)
exports.getAllTickets = async (req, res) => {
  try {
    const result = await db.query(
      "SELECT * FROM support_tickets ORDER BY created_at DESC"
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar todos chamados:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
