// src/controllers/paymentWebhookController.js
import pool from "../db.js";

/**
 * Webhook do PicPay → recebe notificações de pagamento
 */
export const handlePicPayWebhook = async (req, res) => {
  const payload = req.body;
  const referenceId = payload?.referenceId || null;
  const status = payload?.status?.toLowerCase() || "unknown";

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // 1. Salvar log bruto
    const logResult = await client.query(
      `INSERT INTO payment_webhook_logs (provider, reference_id, status, raw_payload, processed)
       VALUES ($1, $2, $3, $4, FALSE) RETURNING id`,
      ["picpay", referenceId, status, payload]
    );
    const logId = logResult.rows[0].id;

    // 2. Atualizar pagamento se existir
    if (referenceId) {
      const paymentResult = await client.query(
        `SELECT * FROM payments WHERE transacao_id = $1 FOR UPDATE`,
        [referenceId]
      );

      if (paymentResult.rows.length > 0) {
        const payment = paymentResult.rows[0];
        let novoStatus = payment.status;

        if (status === "paid") novoStatus = "pago";
        else if (status === "refunded") novoStatus = "estornado";
        else if (status === "chargeback") novoStatus = "contestacao";
        else if (status === "expired") novoStatus = "expirado";
        else if (status === "created" || status === "pending") novoStatus = "pendente";

        if (novoStatus !== payment.status) {
          await client.query(
            `UPDATE payments SET status = $1 WHERE id = $2`,
            [novoStatus, payment.id]
          );
        }
      } else {
        throw new Error(`Pagamento não encontrado para referenceId ${referenceId}`);
      }
    }

    // 3. Marca log como processado
    await client.query(
      `UPDATE payment_webhook_logs SET processed = TRUE WHERE id = $1`,
      [logId]
    );

    await client.query("COMMIT");

    res.status(200).json({ message: "Webhook processado com sucesso" });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro ao processar webhook:", err);

    // Salvar erro no log se possível
    try {
      await client.query(
        `UPDATE payment_webhook_logs SET error_message = $1 WHERE reference_id = $2`,
        [err.message, referenceId]
      );
    } catch (logErr) {
      console.error("❌ Erro ao salvar erro no log:", logErr);
    }

    res.status(500).json({ message: "Erro ao processar webhook" });
  } finally {
    client.release();
  }
};
