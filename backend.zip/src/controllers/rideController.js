// src/controllers/rideController.js
const pool = require("../db");

// Criar corrida (passageiro solicita)
exports.createRide = async (req, res) => {
  const { origem, destino, categoria } = req.body;

  if (!origem || !destino || !categoria)
    return res.status(400).json({ message: "Origem, destino e categoria são obrigatórios." });

  try {
    const result = await pool.query(
      `INSERT INTO rides (passenger_id, origem, destino, categoria, status, data_criacao)
       VALUES ($1, $2, $3, $4, 'solicitada', NOW()) RETURNING *`,
      [req.user.id, origem, destino, categoria]
    );

    res.status(201).json({ message: "Corrida criada com sucesso.", ride: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao criar corrida:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Motorista aceita corrida
exports.acceptRide = async (req, res) => {
  const { rideId } = req.body;

  try {
    const result = await pool.query(
      `UPDATE rides SET driver_id = $1, status = 'aceita' WHERE id = $2 AND status = 'solicitada' RETURNING *`,
      [req.user.id, rideId]
    );

    if (result.rows.length === 0)
      return res.status(400).json({ message: "Corrida não encontrada ou já aceita." });

    res.json({ message: "Corrida aceita com sucesso.", ride: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao aceitar corrida:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Atualizar status da corrida
exports.updateRideStatus = async (req, res) => {
  const { rideId, status } = req.body;

  const validStatuses = ["em_andamento", "concluida", "cancelada"];
  if (!validStatuses.includes(status))
    return res.status(400).json({ message: "Status inválido." });

  try {
    const result = await pool.query(
      `UPDATE rides SET status = $1 WHERE id = $2 RETURNING *`,
      [status, rideId]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Corrida não encontrada." });

    res.json({ message: "Status atualizado.", ride: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao atualizar status da corrida:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Cancelar corrida
exports.cancelRide = async (req, res) => {
  const { rideId } = req.body;

  try {
    const result = await pool.query(
      `UPDATE rides SET status = 'cancelada' WHERE id = $1 RETURNING *`,
      [rideId]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Corrida não encontrada." });

    res.json({ message: "Corrida cancelada.", ride: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao cancelar corrida:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Histórico de corridas do usuário
exports.getUserRides = async (req, res) => {
  try {
    let result;
    if (req.user.role === "passenger") {
      result = await pool.query(`SELECT * FROM rides WHERE passenger_id = $1 ORDER BY data_criacao DESC`, [req.user.id]);
    } else if (req.user.role === "driver") {
      result = await pool.query(`SELECT * FROM rides WHERE driver_id = $1 ORDER BY data_criacao DESC`, [req.user.id]);
    } else {
      return res.status(403).json({ message: "Apenas passageiros ou motoristas podem ver corridas." });
    }

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar histórico de corridas:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Detalhes de uma corrida específica
exports.getRideDetails = async (req, res) => {
  const { rideId } = req.params;

  try {
    const result = await pool.query(`SELECT * FROM rides WHERE id = $1`, [rideId]);

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Corrida não encontrada." });

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao buscar detalhes da corrida:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};