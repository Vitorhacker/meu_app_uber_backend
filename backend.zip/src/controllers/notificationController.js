// src/controllers/notificationController.js
const db = require("../db");

// Criar notificação para um usuário
exports.createNotification = async (req, res) => {
  try {
    const { user_id, title, message, type } = req.body;

    if (!user_id || !title || !message) {
      return res.status(400).json({ message: "user_id, title e message são obrigatórios" });
    }

    const result = await db.query(
      `INSERT INTO notifications (user_id, title, message, type, status)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [user_id, title, message, type || "general", "unread"]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao criar notificação:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar notificações de um usuário
exports.getUserNotifications = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      "SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC",
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar notificações do usuário:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Marcar notificação como lida
exports.markAsRead = async (req, res) => {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await db.query(
      `UPDATE notifications
       SET status = 'read', updated_at = NOW()
       WHERE id = $1 AND user_id = $2
       RETURNING *`,
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Notificação não encontrada" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao marcar notificação como lida:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Deletar notificação
exports.deleteNotification = async (req, res) => {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await db.query(
      "DELETE FROM notifications WHERE id = $1 AND user_id = $2 RETURNING *",
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Notificação não encontrada" });
    }

    res.json({ message: "Notificação removida com sucesso" });
  } catch (err) {
    console.error("❌ Erro ao deletar notificação:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
