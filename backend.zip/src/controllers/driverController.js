```javascript
// src/controllers/driverController.js
const pool = require("../db");

// Registrar motorista e veículo
exports.registerDriver = async (req, res) => {
  const { nome, email, telefone, cnh, placa, modelo, cor } = req.body;

  if (!nome || !email || !telefone || !cnh || !placa || !modelo)
    return res.status(400).json({ message: "Todos os campos obrigatórios devem ser preenchidos." });

  try {
    const driver = await pool.query(
      `INSERT INTO drivers (nome, email, telefone, cnh, status, criado_em)
       VALUES ($1, $2, $3, $4, 'ativo', NOW()) RETURNING *`,
      [nome, email, telefone, cnh]
    );

    const vehicle = await pool.query(
      `INSERT INTO vehicles (driver_id, placa, modelo, cor, status, criado_em)
       VALUES ($1, $2, $3, $4, 'ativo', NOW()) RETURNING *`,
      [driver.rows[0].id, placa, modelo, cor]
    );

    res.status(201).json({ message: "Motorista cadastrado com sucesso.", driver: driver.rows[0], vehicle: vehicle.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao registrar motorista:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Atualizar informações do motorista
exports.updateDriver = async (req, res) => {
  const { id } = req.params;
  const { nome, telefone, status } = req.body;

  try {
    const result = await pool.query(
      `UPDATE drivers SET nome = COALESCE($1, nome), telefone = COALESCE($2, telefone), status = COALESCE($3, status)
       WHERE id = $4 RETURNING *`,
      [nome, telefone, status, id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Motorista não encontrado." });

    res.json({ message: "Motorista atualizado.", driver: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao atualizar motorista:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Listar motoristas
exports.listDrivers = async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM drivers ORDER BY criado_em DESC`);
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao listar motoristas:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Detalhes de motorista + veículo
exports.getDriverDetails = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT d.*, v.placa, v.modelo, v.cor, v.status as veiculo_status
       FROM drivers d
       LEFT JOIN vehicles v ON d.id = v.driver_id
       WHERE d.id = $1`,
      [id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Motorista não encontrado." });

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao buscar detalhes do motorista:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};

// Alterar status de disponibilidade do motorista
exports.toggleAvailability = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `UPDATE drivers SET disponivel = NOT disponivel WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0)
      return res.status(404).json({ message: "Motorista não encontrado." });

    res.json({ message: "Disponibilidade atualizada.", driver: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao alterar disponibilidade:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
};
```
