// src/controllers/walletController.js
const db = require("../db");

// Consultar saldo da carteira
exports.getBalance = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Carteira não encontrada" });
    }

    res.json({ balance: result.rows[0].balance });
  } catch (err) {
    console.error("❌ Erro ao buscar saldo:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Adicionar fundos
exports.addFunds = async (req, res) => {
  try {
    const userId = req.user.id;
    const { amount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ message: "Valor inválido" });
    }

    await db.query("UPDATE wallets SET balance = balance + $1 WHERE user_id = $2", [
      amount,
      userId,
    ]);

    await db.query(
      "INSERT INTO transactions (user_id, type, amount, status) VALUES ($1, $2, $3, $4)",
      [userId, "credit", amount, "completed"]
    );

    res.json({ message: "Saldo adicionado com sucesso" });
  } catch (err) {
    console.error("❌ Erro ao adicionar fundos:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Solicitar saque (vai para payout_requests como 'pending')
exports.withdrawFunds = async (req, res) => {
  try {
    const userId = req.user.id;
    const { amount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ message: "Valor inválido" });
    }

    // Verifica saldo
    const result = await db.query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Carteira não encontrada" });
    }

    const balance = parseFloat(result.rows[0].balance);

    if (balance <= 0 || balance < amount) {
      return res.status(400).json({ message: "Saldo insuficiente" });
    }

    // Cria solicitação de saque (pendente)
    await db.query(
      "INSERT INTO payout_requests (user_id, amount, status, requested_at) VALUES ($1, $2, $3, NOW())",
      [userId, amount, "pending"]
    );

    // Lança no histórico de transações (status = pending)
    await db.query(
      "INSERT INTO transactions (user_id, type, amount, status) VALUES ($1, $2, $3, $4)",
      [userId, "debit", amount, "pending"]
    );

    res.json({ message: "Saque solicitado e aguarda aprovação" });
  } catch (err) {
    console.error("❌ Erro ao solicitar saque:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Histórico da carteira
exports.getWalletHistory = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      "SELECT id, type, amount, status, created_at FROM transactions WHERE user_id = $1 ORDER BY created_at DESC",
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar histórico da carteira:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};

// Listar solicitações de saque do usuário
exports.getPayoutRequests = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      "SELECT id, amount, status, requested_at, processed_at FROM payout_requests WHERE user_id = $1 ORDER BY requested_at DESC",
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar solicitações de saque:", err);
    res.status(500).json({ message: "Erro no servidor" });
  }
};
