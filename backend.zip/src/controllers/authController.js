// src/controllers/authController.js
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("../db");

const JWT_SECRET = process.env.JWT_SECRET || "supersegredo123";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

// Roles válidos
const VALID_ROLES = ["passageiro", "motorista", "admin"];
function normalizeRole(role) {
  if (!role) return "passageiro";
  const r = String(role).toLowerCase();
  return VALID_ROLES.includes(r) ? r : "passageiro";
}

exports.register = async (req, res) => {
  try {
    const { nome, email, senha, role } = req.body;
    if (!nome || !email || !senha) {
      return res.status(400).json({ error: "Dados incompletos" });
    }

    const userRole = normalizeRole(role);

    // verifica se email já existe
    const exists = await pool.query("SELECT id FROM usuarios WHERE email = $1", [email]);
    if (exists.rows.length > 0) {
      return res.status(400).json({ error: "E-mail já cadastrado" });
    }

    const hashed = await bcrypt.hash(senha, 10);

    const q = `
      INSERT INTO usuarios (nome, email, senha, role)
      VALUES ($1,$2,$3,$4)
      RETURNING id, nome, email, role, created_at
    `;
    const result = await pool.query(q, [nome, email, hashed, userRole]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("[auth.register]", err);
    res.status(500).json({ error: "Erro no servidor" });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) {
      return res.status(400).json({ error: "Dados incompletos" });
    }

    const result = await pool.query("SELECT * FROM usuarios WHERE email = $1", [email]);
    if (result.rows.length === 0) {
      return res.status(400).json({ error: "Usuário não encontrado" });
    }

    const user = result.rows[0];
    const ok = await bcrypt.compare(senha, user.senha);
    if (!ok) return res.status(400).json({ error: "Senha inválida" });

    const token = jwt.sign(
      { id: user.id, role: user.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    res.json({
      token,
      user: {
        id: user.id,
        nome: user.nome,
        email: user.email,
        role: user.role,
      },
    });
  } catch (err) {
    console.error("[auth.login]", err);
    res.status(500).json({ error: "Erro no servidor" });
  }
};
