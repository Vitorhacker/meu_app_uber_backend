const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const authMiddleware = require("../middlewares/authMiddleware");

// ======================================================
// 📍 Rota de registro de passageiro
// ======================================================
router.post("/register", (req, res) => {
  console.log("🚀 [ROUTE] POST /auth/register");
  return authController.registerPassenger(req, res);
});

// ======================================================
// 🔑 Login do passageiro
// ======================================================
router.post("/login", (req, res) => {
  console.log("🚀 [ROUTE] POST /auth/login");
  return authController.loginPassenger(req, res);
});

// ======================================================
// 👤 Perfil do usuário logado
// ======================================================
router.get("/profile", authMiddleware, (req, res) => {
  console.log("📡 [ROUTE] GET /auth/profile");
  return authController.getProfile(req, res);
});

// ======================================================
// 🚪 Logout do usuário
// ======================================================
router.post("/logout", authMiddleware, (req, res) => {
  console.log("🚪 [ROUTE] POST /auth/logout");
  return authController.logout(req, res);
});

module.exports = router;
