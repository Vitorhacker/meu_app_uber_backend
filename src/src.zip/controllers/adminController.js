const pool = require("../db");

exports.example = async (req, res, next) => {
  const errors = [];
  if (!req.body.name) errors.push("Nome é obrigatório");
  if (errors.length > 0) return next({ type: "validation", errors });

  try {
    const result = await pool.query("SELECT NOW()");
    res.json({ success: true, result: result.rows[0] });
  } catch (err) {
    next(err);
  }
};
