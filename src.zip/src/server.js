// src/server.js
import express from "express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import dotenv from "dotenv";

import pool from "./db.js";

// Rotas
import authRoutes from "./routes/authRoutes.js";
import rideRoutes from "./routes/rideRoutes.js";
import paymentRoutes from "./routes/paymentRoutes.js";
import driverRoutes from "./routes/driverRoutes.js";
import passengerRoutes from "./routes/passengerRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import walletRoutes from "./routes/walletRoutes.js";
import supportRoutes from "./routes/supportRoutes.js";
import ratingRoutes from "./routes/ratingRoutes.js";
import chatRoutes from "./routes/chatRoutes.js";
import locationRoutes from "./routes/locationRoutes.js";
import transactionRoutes from "./routes/transactionRoutes.js";
import vehicleRoutes from "./routes/vehicleRoutes.js";
import notificationRoutes from "./routes/notificationRoutes.js";
import paymentWebhookRoutes from "./routes/paymentWebhookRoutes.js";

// Polling job (PicPay)
import { startPolling } from "./jobs/picpayPollingJob.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// ======================
// Middlewares
// ======================
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));
app.use(helmet());

// ======================
// Rotas principais da API
// ======================
app.use("/api/auth", authRoutes);
app.use("/api/rides", rideRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/drivers", driverRoutes);
app.use("/api/passengers", passengerRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/support", supportRoutes);
app.use("/api/ratings", ratingRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/location", locationRoutes);
app.use("/api/transactions", transactionRoutes);
app.use("/api/vehicles", vehicleRoutes);
app.use("/api/notifications", notificationRoutes);

// ======================
// Webhooks (PicPay)
// ======================
app.use("/api/webhooks/payments", paymentWebhookRoutes);

// ======================
// Rota de retorno do PicPay
// ======================
app.get("/app/checkout-return", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Pagamento Processado</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: #f4f4f9;
          }
          .card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            max-width: 400px;
            margin: auto;
            box-shadow: 0px 2px 8px rgba(0,0,0,0.1);
          }
          h1 {
            color: #22c55e;
          }
          p {
            color: #333;
          }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>✅ Pagamento em processamento!</h1>
          <p>Obrigado por utilizar nosso app.<br>
          Assim que o PicPay confirmar o pagamento,<br>
          sua corrida será liberada automaticamente.</p>
        </div>
      </body>
    </html>
  `);
});

// ======================
// Healthcheck
// ======================
app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", db: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", db: "disconnected" });
  }
});

// ======================
// Ativar polling do PicPay
// ======================
if (process.env.ENABLE_PICPAY_POLLING === "true") {
  startPolling();
}

// ======================
// Rota inicial de teste
// ======================
app.get("/", (req, res) => {
  res.send("🚀 API do App de Transporte funcionando!");
});

// ======================
// Middleware global de erros
// ======================
app.use((err, req, res, next) => {
  console.error("❌ Erro não tratado:", err);
  res.status(500).json({ error: "Erro interno do servidor" });
});

// ======================
// Iniciar servidor
// ======================
const server = app.listen(PORT, () => {
  console.log(`✅ Servidor rodando na porta ${PORT}`);
});

// ======================
// Graceful shutdown
// ======================
process.on("SIGTERM", async () => {
  console.log("🔻 Encerrando servidor...");
  await pool.end();
  server.close(() => {
    console.log("✅ Conexões fechadas. Servidor encerrado.");
    process.exit(0);
  });
});
