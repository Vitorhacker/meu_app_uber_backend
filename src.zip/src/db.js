// src/config/db.js
import pg from "pg";

const { Pool } = pg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false } // Railway/Heroku exigem SSL
      : false,
  min: parseInt(process.env.PGPOOL_MIN || "2", 10),
  max: parseInt(process.env.PGPOOL_MAX || "10", 10),
  idleTimeoutMillis: parseInt(process.env.PGPOOL_IDLE_TIMEOUT || "30000", 10),
});

// Testa conexão inicial
pool
  .connect()
  .then((client) => {
    console.log("✅ Conectado ao PostgreSQL");
    client.release();
  })
  .catch((err) => console.error("❌ Erro ao conectar no PostgreSQL:", err));

// Heartbeat para evitar timeout em Railway/Heroku
setInterval(async () => {
  try {
    await pool.query("SELECT 1");
    console.log("💓 PostgreSQL heartbeat ok");
  } catch (err) {
    console.error("❌ Erro no heartbeat PostgreSQL:", err.message);
  }
}, 60 * 1000); // a cada 1 minuto

export default pool;
