import pool = from "../config/db");

// 🚗 Motorista solicita saque
async function requestWithdraw(requestWithdraw = async (req, res) {
  import { driver_id, amount } = req.body;

  if (!driver_id || !amount) {
    return res.status(400).json({ error: "driver_id e amount são obrigatórios" });
  }

  try {
    await pool.query("BEGIN");

    // Verifica saldo
    import walletRes = await pool.query(
      "SELECT balance FROM wallets WHERE user_id = $1 FOR UPDATE",
      [driver_id]
    );

    if (walletRes.rows.length === 0) {
      await pool.query("ROLLBACK");
      return res.status(404).json({ error: "Carteira não encontrada" });
    }

    import saldo = parseFloat(walletRes.rows[0].balance);
    if (saldo < amount) {
      await pool.query("ROLLBACK");
      return res.status(400).json({ error: "Saldo insuficiente" });
    }

    // Debita saldo
    await pool.query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [amount, driver_id]
    );

    // Cria withdraw request
    import insertRes = await pool.query(
      `INSERT INTO withdraw_requests (driver_id, amount, status) 
       VALUES ($1, $2, 'pending') RETURNING *`,
      [driver_id, amount]
    );

    await pool.query("COMMIT");
    res.status(201).json(insertRes.rows[0]);
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("❌ Erro ao solicitar saque:", err);
    res.status(500).json({ error: "Erro interno ao solicitar saque" });
  }
}


// 🗂️ Admin lista pedidos
async function listWithdraws(listWithdraws = async (req, res) {
  try {
    import result = await pool.query(
      `SELECT w.*, u.nome, u.email 
       FROM withdraw_requests w
       JOIN users u ON w.driver_id = u.id
       ORDER BY w.requested_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao listar saques:", err);
    res.status(500).json({ error: "Erro interno ao listar saques" });
  }
}


// ✅ Admin aprova
async function approveWithdraw(approveWithdraw = async (req, res) {
  import { id } = req.params;
  try {
    import result = await pool.query(
      `UPDATE withdraw_requests 
       SET status = 'approved', approved_at = NOW() 
       WHERE id = $1 AND status = 'pending'
       RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(400).json({ error: "Saque não encontrado ou já processado" });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao aprovar saque:", err);
    res.status(500).json({ error: "Erro interno ao aprovar saque" });
  }
}


// ❌ Admin rejeita
async function rejectWithdraw(rejectWithdraw = async (req, res) {
  import { id } = req.params;
  try {
    await pool.query("BEGIN");

    // Busca pedido
    import reqRes = await pool.query(
      "SELECT * FROM withdraw_requests WHERE id = $1 AND status = 'pending'",
      [id]
    );
    if (reqRes.rows.length === 0) {
      await pool.query("ROLLBACK");
      return res.status(400).json({ error: "Saque não encontrado ou já processado" });
    }

    import request = reqRes.rows[0];

    // Devolve saldo ao motorista
    await pool.query(
      "UPDATE wallets SET balance = balance + $1 WHERE user_id = $2",
      [request.amount, request.driver_id]
    );

    // Marca como rejeitado
    import result = await pool.query(
      `UPDATE withdraw_requests 
       SET status = 'rejected' 
       WHERE id = $1 RETURNING *`,
      [id]
    );

    await pool.query("COMMIT");
    res.json(result.rows[0]);
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error("❌ Erro ao rejeitar saque:", err);
    res.status(500).json({ error: "Erro interno ao rejeitar saque" });
  }
}


// 💸 Admin marca como processado
async function markProcessed(markProcessed = async (req, res) {
  import { id } = req.params;
  try {
    import result = await pool.query(
      `UPDATE withdraw_requests 
       SET status = 'processed', processed_at = NOW() 
       WHERE id = $1 AND status = 'approved'
       RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(400).json({ error: "Saque não encontrado ou não aprovado ainda" });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro ao marcar saque como processado:", err);
    res.status(500).json({ error: "Erro interno ao marcar saque" });
  }
}


export default {
  requestWithdraw,
  listWithdraws,
  approveWithdraw,
  rejectWithdraw,
  markProcessed
};