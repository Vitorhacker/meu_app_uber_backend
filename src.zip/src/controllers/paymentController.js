// src/controllers/paymentController.js
import pool from "../db.js";
import { createCharge, getPayment, refundPayment as picpayRefund } from "../services/picpayService.js";

// Criar pagamento vinculado a uma corrida
async function createPayment(req, res) {
  const { rideId, metodo, valor, buyer } = req.body;

  if (!rideId || !metodo || !valor) {
    return res.status(400).json({ message: "rideId, metodo e valor são obrigatórios." });
  }

  const client = await pool.connect();
  const referenceId = `ride_${rideId}_${Date.now()}`;

  try {
    await client.query("BEGIN");

    const rideCheck = await client.query(`SELECT * FROM rides WHERE id = $1`, [rideId]);
    if (rideCheck.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Corrida não encontrada." });
    }

    const insert = await client.query(
      `INSERT INTO payments (ride_id, valor, metodo, status, transacao_id, provider, data_pagamento)
       VALUES ($1,$2,$3,'pendente',$4,$5,NOW()) RETURNING *`,
      [rideId, valor, metodo, referenceId, metodo === "picpay" ? "picpay" : metodo]
    );

    const payment = insert.rows[0];
    let providerResp = null;

    if (metodo === "picpay") {
      providerResp = await createCharge({ referenceId, value: valor, buyer });
    }

    await client.query("COMMIT");
    res.status(201).json({ message: "Pagamento criado.", payment, provider: providerResp });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro ao criar pagamento:", err);
    res.status(500).json({ message: "Erro ao criar pagamento." });
  } finally {
    client.release();
  }
}

// Confirmar pagamento
async function confirmPayment(req, res) {
  const { paymentId } = req.body;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query(`SELECT * FROM payments WHERE id=$1 FOR UPDATE`, [paymentId]);
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Pagamento não encontrado." });
    }
    const payment = result.rows[0];

    if (payment.metodo === "picpay") {
      const status = await getPayment(payment.transacao_id);
      if (!status || status.status !== "paid") {
        await client.query("ROLLBACK");
        return res.status(400).json({ message: "Pagamento PicPay ainda não confirmado." });
      }
    }

    await client.query(`UPDATE payments SET status='pago', data_pagamento=NOW() WHERE id=$1`, [paymentId]);

    await processSplit(client, payment);

    await client.query("COMMIT");
    res.json({ message: "Pagamento confirmado e contabilizado.", paymentId: payment.id });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro confirmPayment:", err);
    res.status(500).json({ message: "Erro no servidor." });
  } finally {
    client.release();
  }
}

// Verificar pagamento por referência
async function verifyPaymentByReference(req, res) {
  const { referenceId } = req.body;
  if (!referenceId) return res.status(400).json({ message: "referenceId é obrigatório." });

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query(`SELECT * FROM payments WHERE transacao_id=$1 FOR UPDATE`, [referenceId]);
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Pagamento não encontrado." });
    }
    const payment = result.rows[0];

    if (payment.status === "pago") {
      await client.query("ROLLBACK");
      return res.json({ message: "Pagamento já confirmado.", paymentId: payment.id });
    }

    const status = await getPayment(referenceId);
    if (!status || status.status !== "paid") {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Pagamento ainda não confirmado no provedor." });
    }

    await client.query(`UPDATE payments SET status='pago', data_pagamento=NOW() WHERE id=$1`, [payment.id]);

    await processSplit(client, payment);

    await client.query("COMMIT");
    res.json({ message: "Pagamento verificado e contabilizado.", paymentId: payment.id });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro verifyPaymentByReference:", err);
    res.status(500).json({ message: "Erro no servidor." });
  } finally {
    client.release();
  }
}

// Histórico
async function getUserPayments(req, res) {
  try {
    let result;
    if (req.user.role === "passenger") {
      result = await pool.query(
        `SELECT p.* FROM payments p JOIN rides r ON p.ride_id=r.id WHERE r.passenger_id=$1 ORDER BY p.data_pagamento DESC`,
        [req.user.id]
      );
    } else if (req.user.role === "driver") {
      result = await pool.query(
        `SELECT p.* FROM payments p JOIN rides r ON p.ride_id=r.id WHERE r.driver_id=$1 ORDER BY p.data_pagamento DESC`,
        [req.user.id]
      );
    } else {
      return res.status(403).json({ message: "Apenas passageiros ou motoristas podem ver pagamentos." });
    }
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro getUserPayments:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

// Estorno
async function refundPayment(req, res) {
  const { paymentId } = req.body;

  try {
    const result = await pool.query(`SELECT * FROM payments WHERE id=$1`, [paymentId]);
    if (result.rows.length === 0) return res.status(404).json({ message: "Pagamento não encontrado." });

    const payment = result.rows[0];
    if (payment.metodo === "picpay") {
      await picpayRefund(payment.transacao_id, payment.valor);
    }

    const updated = await pool.query(
      `UPDATE payments SET status='estornado' WHERE id=$1 RETURNING *`,
      [paymentId]
    );

    res.json({ message: "Pagamento estornado.", payment: updated.rows[0] });
  } catch (err) {
    console.error("❌ Erro refundPayment:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

// Processar split
async function processSplit(client, payment) {
  const rideRes = await client.query(`SELECT * FROM rides WHERE id=$1 FOR UPDATE`, [payment.ride_id]);
  if (rideRes.rows.length === 0) return;
  const ride = rideRes.rows[0];

  const passengerId = ride.passenger_id;
  const driverId = ride.driver_id;

  const feePercent = parseFloat(process.env.PLATFORM_FEE_PERCENT || "0.20");
  const platformFee = Number((parseFloat(payment.valor) * feePercent).toFixed(2));
  const driverShare = Number((parseFloat(payment.valor) - platformFee).toFixed(2));

  // Debita passageiro
  await adjustWallet(client, passengerId, -payment.valor, "ride_payment_debit", payment, ride);

  // Credita motorista
  await adjustWallet(client, driverId, driverShare, "driver_earn", payment, ride);

  // Credita plataforma
  const platformUserId = parseInt(process.env.PLATFORM_USER_ID || "0", 10);
  if (platformUserId) {
    await adjustWallet(client, platformUserId, platformFee, "platform_fee", payment, ride);
  }

  await client.query(`UPDATE rides SET status='concluida', finalizado_em=NOW() WHERE id=$1`, [ride.id]);
}

// Atualiza carteira
async function adjustWallet(client, userId, amount, type, payment, ride) {
  const w = await client.query("SELECT id,balance FROM wallets WHERE user_id=$1 FOR UPDATE", [userId]);
  let newBalance;
  if (w.rows.length === 0) {
    newBalance = amount;
    await client.query(
      "INSERT INTO wallets (user_id,balance,reserved,currency,updated_at) VALUES ($1,$2,0,'BRL',NOW())",
      [userId, newBalance]
    );
  } else {
    const cur = Number(w.rows[0].balance || 0);
    newBalance = Number((cur + amount).toFixed(2));
    await client.query("UPDATE wallets SET balance=$1, updated_at=NOW() WHERE id=$2", [newBalance, w.rows[0].id]);
  }

  await client.query(
    `INSERT INTO ledger_entries (user_id,related_table,related_id,type,amount,balance_after,metadata)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [userId, "payments", payment.id, type, amount, newBalance, JSON.stringify({ ride_id: ride.id, provider: payment.provider })]
  );
}

export default {
  createPayment,
  confirmPayment,
  verifyPaymentByReference,
  getUserPayments,
  refundPayment,
};
