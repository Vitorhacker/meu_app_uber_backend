import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../db.js";
import crypto from "crypto";
import nodemailer from "nodemailer";

const JWT_SECRET = process.env.JWT_SECRET || "supersegredo123";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

async function sendEmail(to, subject, text) {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    await transporter.sendMail({
      from: `Flash App <${process.env.SMTP_USER}>`,
      to,
      subject,
      text,
    });
  } catch (err) {
    console.error("❌ Erro no envio de e-mail:", err);
  }
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

async function register(req, res) {
  const { nome, email, senha, role, telefone, documento, veiculo } = req.body;
  if (!nome || !email || !senha || !role)
    return res.status(400).json({ message: "Dados obrigatórios faltando." });

  try {
    const hashedPassword = await bcrypt.hash(senha, 10);
    const result = await pool.query(
      `INSERT INTO users (name, email, password_hash, role, phone) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [nome, email, hashedPassword, role, telefone || null]
    );

    const user = result.rows[0];
    if (role === "driver") {
      await pool.query(
        `INSERT INTO drivers (user_id, license_number, vehicle_info) VALUES ($1, $2, $3)`,
        [user.id, documento || null, veiculo || null]
      );
    } else if (role === "passenger") {
      await pool.query(`INSERT INTO passengers (user_id) VALUES ($1)`, [user.id]);
    }

    res.status(201).json({
      message: "Usuário registrado com sucesso.",
      token: generateToken(user),
      user,
    });
  } catch (err) {
    console.error("❌ Erro no registro:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

async function login(req, res) {
  const { email, senha } = req.body;
  try {
    const result = await pool.query(`SELECT * FROM users WHERE email = $1`, [email]);
    if (result.rows.length === 0)
      return res.status(400).json({ message: "Usuário não encontrado." });

    const user = result.rows[0];
    const isMatch = await bcrypt.compare(senha, user.password_hash);
    if (!isMatch) return res.status(401).json({ message: "Senha incorreta." });

    res.json({
      message: "Login bem-sucedido.",
      token: generateToken(user),
      user,
    });
  } catch (err) {
    console.error("❌ Erro no login:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

async function getProfile(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, name, email, role, phone, created_at FROM users WHERE id = $1`,
      [req.user.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ message: "Usuário não encontrado." });

    res.json(result.rows[0]);
  } catch (err) {
    console.error("❌ Erro no perfil:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

async function updateProfile(req, res) {
  const { nome, telefone } = req.body;
  try {
    const result = await pool.query(
      `UPDATE users SET name = $1, phone = $2 WHERE id = $3 RETURNING id, name, email, role, phone`,
      [nome, telefone, req.user.id]
    );
    res.json({ message: "Perfil atualizado.", user: result.rows[0] });
  } catch (err) {
    console.error("❌ Erro ao atualizar perfil:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

async function forgotPassword(req, res) {
  const { email } = req.body;
  try {
    const result = await pool.query(`SELECT * FROM users WHERE email = $1`, [email]);
    if (result.rows.length === 0)
      return res.status(400).json({ message: "Usuário não encontrado." });

    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetTokenHash = await bcrypt.hash(resetToken, 10);
    await pool.query(
      `UPDATE users SET reset_token = $1, reset_token_expires = NOW() + interval '1 hour' WHERE email = $2`,
      [resetTokenHash, email]
    );

    const resetUrl = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;
    await sendEmail(email, "Recuperação de senha", `Clique para resetar: ${resetUrl}`);
    res.json({ message: "E-mail de recuperação enviado." });
  } catch (err) {
    console.error("❌ Erro no esqueci minha senha:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

async function resetPassword(req, res) {
  const { token, novaSenha } = req.body;
  try {
    const result = await pool.query(`SELECT * FROM users WHERE reset_token_expires > NOW()`);
    const user = result.rows.find((u) => bcrypt.compareSync(token, u.reset_token));
    if (!user) return res.status(400).json({ message: "Token inválido ou expirado." });

    const hashedPassword = await bcrypt.hash(novaSenha, 10);
    await pool.query(
      `UPDATE users SET password_hash = $1, reset_token = NULL, reset_token_expires = NULL WHERE id = $2`,
      [hashedPassword, user.id]
    );
    res.json({ message: "Senha redefinida com sucesso." });
  } catch (err) {
    console.error("❌ Erro ao resetar senha:", err);
    res.status(500).json({ message: "Erro no servidor." });
  }
}

export default {
  register,
  login,
  getProfile,
  updateProfile,
  forgotPassword,
  resetPassword
};