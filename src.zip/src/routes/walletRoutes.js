import express from "express";
import * as walletController from "../controllers/walletController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.get("/", verifyToken, walletController.getWallet);
router.post("/deposit", verifyToken, walletController.deposit);
router.post("/withdraw", verifyToken, walletController.withdraw);

export default router;
