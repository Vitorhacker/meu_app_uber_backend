import express from "express";
import * as adminController from "../controllers/adminController.js";
import { verifyToken, requireRole } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.get("/drivers", verifyToken, requireRole("admin"), adminController.listAllDrivers);
router.get("/passengers", verifyToken, requireRole("admin"), adminController.listAllPassengers);
router.get("/rides", verifyToken, requireRole("admin"), adminController.listAllRides);

export default router;
