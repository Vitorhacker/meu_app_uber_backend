import express from "express";
import * as driverController from "../controllers/driverController.js";
import { verifyToken, requireRole } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.get("/", verifyToken, requireRole("admin"), driverController.listDrivers);
router.post("/register", driverController.registerDriver);

export default router;
