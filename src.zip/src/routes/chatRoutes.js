import express from "express";
import * as chatController from "../controllers/chatController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/send", verifyToken, chatController.sendMessage);
router.get("/history/:rideId", verifyToken, chatController.getChatHistory);

export default router;
