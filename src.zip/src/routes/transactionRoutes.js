import express from "express";
import * as transactionController from "../controllers/transactionController.js";
import { verifyToken, requireRole } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/create", verifyToken, transactionController.createTransaction);
router.get("/history/user", verifyToken, transactionController.getUserTransactions);
router.get("/all", verifyToken, requireRole("admin"), transactionController.getAllTransactions);

export default router;
