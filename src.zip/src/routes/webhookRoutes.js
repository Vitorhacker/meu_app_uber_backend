import express from "express";
import { handlePicpayWebhook } from "../controllers/webhookController.js";

const router = express.Router();

// Endpoint que o PicPay vai chamar
router.post("/picpay", handlePicpayWebhook);

export default router;
