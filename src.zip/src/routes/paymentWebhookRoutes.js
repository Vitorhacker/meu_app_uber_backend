import express from "express";
import * as webhookController from "../controllers/paymentWebhookController.js";

const router = express.Router();

router.post("/", webhookController.handleWebhook);

export default router;
