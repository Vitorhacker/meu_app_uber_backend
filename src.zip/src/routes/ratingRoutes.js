import express from "express";
import * as ratingController from "../controllers/ratingController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/", verifyToken, ratingController.addRating);
router.get("/:rideId", verifyToken, ratingController.getRatingsByRide);

export default router;
