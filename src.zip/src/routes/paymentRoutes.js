import express from "express";
import * as paymentController from "../controllers/paymentController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/checkout", verifyToken, paymentController.createCheckout);
router.get("/status/:id", verifyToken, paymentController.getPaymentStatus);

export default router;
