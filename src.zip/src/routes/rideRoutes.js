import express from "express";
import * as rideController from "../controllers/rideController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/create", verifyToken, rideController.createRide);
router.get("/history", verifyToken, rideController.getUserRides);

export default router;
