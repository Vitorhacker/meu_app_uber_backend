import express from "express";
import * as passengerController from "../controllers/passengerController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.get("/", verifyToken, passengerController.getPassengers);
router.post("/register", passengerController.registerPassenger);

export default router;
