import express from "express";
import * as vehicleController from "../controllers/vehicleController.js";
import { verifyToken, requireRole } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/register", verifyToken, requireRole("driver"), vehicleController.registerVehicle);
router.put("/update/:id", verifyToken, requireRole("driver"), vehicleController.updateVehicle);
router.get("/my-vehicles", verifyToken, requireRole("driver"), vehicleController.getDriverVehicles);
router.delete("/delete/:id", verifyToken, requireRole("driver"), vehicleController.deleteVehicle);
router.get("/all", verifyToken, requireRole("admin"), vehicleController.getAllVehicles);

export default router;
