import express from "express";
import * as supportController from "../controllers/supportController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/", verifyToken, supportController.createTicket);
router.get("/", verifyToken, supportController.getTickets);

export default router;
