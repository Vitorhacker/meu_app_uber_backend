import express from "express";
import * as notificationController from "../controllers/notificationController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.get("/", verifyToken, notificationController.getUserNotifications);
router.post("/mark-read/:id", verifyToken, notificationController.markAsRead);

export default router;
