import express from "express";
import * as locationController from "../controllers/locationController.js";
import { verifyToken } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/update", verifyToken, locationController.updateLocation);
router.get("/track/:rideId", verifyToken, locationController.trackRide);

export default router;
