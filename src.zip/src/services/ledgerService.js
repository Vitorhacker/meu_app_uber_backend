// src/services/ledgerService.js
// Ledger: gerencia carteiras, saldos e lançamentos de crédito/débito.

import pool from "../db.js";

/**
 * ensureWallet(userId, role)
 * - Garante que o usuário tem uma carteira criada.
 */
export async function ensureWallet(userId, role) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { rows } = await client.query(
      "SELECT id FROM wallets WHERE user_id = $1 FOR UPDATE",
      [userId]
    );

    if (rows.length === 0) {
      await client.query(
        `INSERT INTO wallets (user_id, saldo, status, tipo)
         VALUES ($1, 0, 'ativo', $2)`,
        [userId, role]
      );
    }

    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/**
 * addLedgerEntry
 * Cria lançamento e atualiza saldo da carteira.
 */
export async function addLedgerEntry({
  userId,
  role,
  type,
  amount,
  refType,
  refId,
  description,
}) {
  if (!["credito", "debito"].includes(type)) {
    throw new Error("Tipo inválido: use credito ou debito");
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { rows: wallets } = await client.query(
      "SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE",
      [userId]
    );

    if (wallets.length === 0) {
      throw new Error(`Carteira não encontrada para user ${userId}`);
    }

    const wallet = wallets[0];
    let novoSaldo = parseFloat(wallet.saldo);

    if (type === "credito") novoSaldo += parseFloat(amount);
    else if (type === "debito") novoSaldo -= parseFloat(amount);

    await client.query(
      `INSERT INTO ledger_entries
       (wallet_id, tipo, valor, referencia_tipo, referencia_id, descricao)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [wallet.id, type, amount, refType, refId, description]
    );

    await client.query("UPDATE wallets SET saldo = $1 WHERE id = $2", [
      novoSaldo,
      wallet.id,
    ]);

    await client.query("COMMIT");

    return { walletId: wallet.id, saldo: novoSaldo };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/**
 * getWallet(userId)
 */
export async function getWallet(userId) {
  const { rows } = await pool.query("SELECT * FROM wallets WHERE user_id = $1", [userId]);
  return rows.length ? rows[0] : null;
}

/**
 * transferBetweenWallets
 */
export async function transferBetweenWallets({
  fromUserId,
  fromRole,
  toUserId,
  toRole,
  amount,
  refType,
  refId,
  description,
}) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { rows: fromWallets } = await client.query(
      "SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE",
      [fromUserId]
    );
    if (fromWallets.length === 0) throw new Error("Carteira origem não encontrada");
    const fromWallet = fromWallets[0];
    if (parseFloat(fromWallet.saldo) < amount) {
      throw new Error("Saldo insuficiente na carteira origem");
    }

    const { rows: toWallets } = await client.query(
      "SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE",
      [toUserId]
    );
    if (toWallets.length === 0) throw new Error("Carteira destino não encontrada");
    const toWallet = toWallets[0];

    await client.query(
      `INSERT INTO ledger_entries
       (wallet_id, tipo, valor, referencia_tipo, referencia_id, descricao)
       VALUES ($1, 'debito', $2, $3, $4, $5)`,
      [fromWallet.id, amount, refType, refId, description]
    );
    await client.query("UPDATE wallets SET saldo = saldo - $1 WHERE id = $2", [
      amount,
      fromWallet.id,
    ]);

    await client.query(
      `INSERT INTO ledger_entries
       (wallet_id, tipo, valor, referencia_tipo, referencia_id, descricao)
       VALUES ($1, 'credito', $2, $3, $4, $5)`,
      [toWallet.id, amount, refType, refId, description]
    );
    await client.query("UPDATE wallets SET saldo = saldo + $1 WHERE id = $2", [
      amount,
      toWallet.id,
    ]);

    await client.query("COMMIT");
    return true;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/**
 * approveWithdraw
 * - Marca saque como pago
 * - Debita carteira do motorista
 * - Lança no ledger
 */
export async function approveWithdraw({ driverId, withdrawId, amount }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { rows: wallets } = await client.query(
      "SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE",
      [driverId]
    );
    if (wallets.length === 0) throw new Error("Carteira do motorista não encontrada");
    const wallet = wallets[0];

    if (parseFloat(wallet.saldo) < amount) {
      throw new Error("Saldo insuficiente para saque");
    }

    await client.query(
      "UPDATE wallets SET saldo = saldo - $1 WHERE id = $2",
      [amount, wallet.id]
    );

    await client.query(
      `INSERT INTO ledger_entries
       (wallet_id, tipo, valor, referencia_tipo, referencia_id, descricao)
       VALUES ($1, 'debito', $2, 'withdraw_requests', $3, 'Saque Pix')`,
      [wallet.id, amount, withdrawId]
    );

    await client.query(
      "UPDATE withdraw_requests SET status = 'paid', paid_at = NOW() WHERE id = $1",
      [withdrawId]
    );

    await client.query("COMMIT");
    return { success: true };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
