// src/services/payoutService.js
import axios from "axios";
import pool from "../db.js";

/**
 * Envia payout para motorista via PicPay
 * @param {number} driverId - ID do motorista
 * @param {number} amount - Valor líquido
 * @param {object} bankAccount - Dados bancários (JSON armazenado em users.bank_account)
 */
export async function sendPayoutToDriver(driverId, amount, bankAccount) {
  const client = await pool.connect();
  const referenceId = `payout_${driverId}_${Date.now()}`;

  try {
    await client.query("BEGIN");

    // 0) Verifica saldo do motorista
    const { rows: walletRows } = await client.query(
      "SELECT balance FROM wallets WHERE user_id = $1 FOR UPDATE",
      [driverId]
    );

    if (walletRows.length === 0) {
      throw new Error("Carteira não encontrada");
    }

    const balance = parseFloat(walletRows[0].balance);
    if (balance <= 0 || balance < amount) {
      throw new Error("Saldo insuficiente para payout");
    }

    // 1) Debita da carteira
    await client.query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [amount, driverId]
    );

    // 2) Cria registro de payout (status = processing)
    const { rows: payoutRows } = await client.query(
      `INSERT INTO driver_payouts (driver_id, amount, status, reference_id, created_at)
       VALUES ($1, $2, 'processing', $3, NOW())
       RETURNING *`,
      [driverId, amount, referenceId]
    );
    const payout = payoutRows[0];

    // 3) Chamada à API do PicPay
    const resp = await axios.post(
      `${process.env.PICPAY_BASE_URL || "https://appws.picpay.com/ecommerce/public"}/payouts`,
      {
        referenceId,
        value: amount,
        bankAccount: {
          bankCode: bankAccount.bankCode,
          agencia: bankAccount.agencia,
          conta: bankAccount.conta,
          tipoConta: bankAccount.tipoConta || "corrente",
          documento: bankAccount.documento, // CPF/CNPJ
          titular: bankAccount.titular,
        },
      },
      {
        headers: {
          "Content-Type": "application/json",
          "x-picpay-token": process.env.PICPAY_API_KEY,
        },
        timeout: 10000,
      }
    );

    const providerData = resp.data;

    // 4) Atualiza payout com provider_reference
    await client.query(
      `UPDATE driver_payouts 
       SET status = 'completed', provider_reference = $1, updated_at = NOW() 
       WHERE id = $2`,
      [providerData.transactionId || providerData.id, payout.id]
    );

    // 5) Cria entrada no ledger
    await client.query(
      `INSERT INTO ledger_entries 
        (user_id, related_table, related_id, type, amount, balance_after, metadata) 
       VALUES ($1, 'driver_payouts', $2, 'payout', $3, (SELECT balance FROM wallets WHERE user_id = $1), $4)`,
      [
        driverId,
        payout.id,
        -amount,
        JSON.stringify({ provider: "picpay", ref: referenceId }),
      ]
    );

    await client.query("COMMIT");

    return { success: true, payoutId: payout.id, provider: providerData };
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Erro em sendPayoutToDriver:", err.message || err);

    throw new Error("Falha ao enviar payout");
  } finally {
    client.release();
  }
}
