import axios from "axios";

const BASE = process.env.PICPAY_API_BASE || "https://api.picpay.com";
const CLIENT_ID = process.env.PICPAY_CLIENT_ID;
const CLIENT_SECRET = process.env.PICPAY_CLIENT_SECRET;
const CALLBACK_URL = process.env.PICPAY_CALLBACK_URL;
const RETURN_URL = process.env.PICPAY_RETURN_URL;

if (!CLIENT_ID || !CLIENT_SECRET) {
  console.warn("⚠️ PICPAY_CLIENT_ID e PICPAY_CLIENT_SECRET não configurados.");
}

let tokenCache = { access_token: null, expires_at: null };

/**
 * Obtém e cacheia o Bearer Token
 */
async function getBearerToken() {
  const now = Date.now();
  if (tokenCache.access_token && tokenCache.expires_at > now) {
    return tokenCache.access_token;
  }

  try {
    const resp = await axios.post(`${BASE}/oauth/token`, {
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      grant_type: "client_credentials",
    });

    const { access_token, expires_in } = resp.data;
    tokenCache = {
      access_token,
      expires_at: now + (expires_in - 30) * 1000, // 30s de margem
    };

    return access_token;
  } catch (err) {
    throw new Error(`Erro ao obter token do PicPay: ${err.message}`);
  }
}

/**
 * Cria uma cobrança
 */
export async function createCharge({
  referenceId,
  value,
  buyer = null,
  expiresMinutes = 30,
  callbackUrl = CALLBACK_URL,
  returnUrl = RETURN_URL,
}) {
  if (!referenceId) throw new Error("referenceId required");
  if (value == null) throw new Error("value required");

  const token = await getBearerToken();
  const expiresAt = new Date(Date.now() + expiresMinutes * 60 * 1000).toISOString();

  const payload = {
    referenceId,
    callbackUrl,
    returnUrl,
    value: parseFloat(value).toFixed(2),
    expiresAt,
  };
  if (buyer) payload.buyer = buyer;

  try {
    const resp = await axios.post(`${BASE}/payments`, payload, {
      headers: { Authorization: `Bearer ${token}` },
      timeout: 15000,
    });
    return resp.data;
  } catch (err) {
    if (err.response) {
      throw new Error(
        `PicPay createCharge failed (${err.response.status}): ${JSON.stringify(err.response.data)}`
      );
    }
    throw new Error(`PicPay createCharge error: ${err.message}`);
  }
}

/**
 * Consulta pagamento
 */
export async function getPayment(referenceId) {
  if (!referenceId) throw new Error("referenceId required");

  const token = await getBearerToken();

  try {
    const resp = await axios.get(`${BASE}/payments/${referenceId}`, {
      headers: { Authorization: `Bearer ${token}` },
      timeout: 10000,
    });
    return resp.data;
  } catch (err) {
    if (err.response) {
      throw new Error(
        `PicPay getPayment failed (${err.response.status}): ${JSON.stringify(err.response.data)}`
      );
    }
    throw new Error(`PicPay getPayment error: ${err.message}`);
  }
}

/**
 * Estorno
 */
export async function refundPayment(referenceId, { authorizationId, value }) {
  if (!referenceId) throw new Error("referenceId required");

  const token = await getBearerToken();

  const payload = {};
  if (authorizationId) payload.authorizationId = authorizationId;
  if (value) payload.value = parseFloat(value).toFixed(2);

  try {
    const resp = await axios.post(`${BASE}/payments/${referenceId}/refunds`, payload, {
      headers: { Authorization: `Bearer ${token}` },
      timeout: 10000,
    });
    return resp.data;
  } catch (err) {
    if (err.response) {
      throw new Error(
        `PicPay refundPayment failed (${err.response.status}): ${JSON.stringify(err.response.data)}`
      );
    }
    throw new Error(`PicPay refundPayment error: ${err.message}`);
  }
}

/**
 * Payout para motorista
 */
export async function sendPayout({ referenceId, value, recipient }) {
  if (!referenceId) throw new Error("referenceId required");
  if (!recipient) throw new Error("recipient required");

  const token = await getBearerToken();

  const payload = {
    referenceId,
    value: parseFloat(value).toFixed(2),
    recipient,
  };

  try {
    const resp = await axios.post(`${BASE}/payouts`, payload, {
      headers: { Authorization: `Bearer ${token}` },
      timeout: 15000,
    });
    return resp.data;
  } catch (err) {
    if (err.response) {
      throw new Error(
        `PicPay sendPayout failed (${err.response.status}): ${JSON.stringify(err.response.data)}`
      );
    }
    throw new Error(`PicPay sendPayout error: ${err.message}`);
  }
}
